/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package culebrita.view;

import java.awt.Frame;

/**
 *
 * @author acwin7ra-01
 */
public class Ventana{
    private Frame frame;

    public Ventana() {
        
        frame = new Frame("Culebrita");
        initComponent();
    }
    
    public void initComponent()
    {
        frame.setSize(500, 250);
        frame.setVisible(true);
    }
}
