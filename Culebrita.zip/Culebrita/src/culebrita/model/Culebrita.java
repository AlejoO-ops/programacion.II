/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package culebrita.model;

/**
 *
 * @author acwin7ra-01
 */
public class Culebrita {
    
    private int longitud;
    private int posx;
    private int posy;
    private String color;

    public Culebrita() {
        this.longitud = 1;
        this.posx = 1;
        this.posy = 1;
        this.color = "red";
    }
    
    public Culebrita(int longitud, int posx, int posy, String color) {
        this.longitud = longitud;
        this.posx = posx;
        this.posy = posy;
        this.color = color;
    }

    public int getLongitud() {
        return longitud;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }

    public int getPosx() {
        return posx;
    }

    public void setPosx(int posx) {
        this.posx = posx;
    }

    public int getPosy() {
        return posy;
    }

    public void setPosy(int posy) {
        this.posy = posy;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    
    
}
