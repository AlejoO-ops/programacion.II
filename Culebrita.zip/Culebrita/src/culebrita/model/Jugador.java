/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package culebrita.model;

/**
 *
 * @author acwin7ra-01
 */
public class Jugador {
    
    private String alias;
    private int puntajePartida;
    private int puntajeMax;
    
    public Jugador() {
        this.puntajePartida = 0;
        this.puntajeMax = 0;
    }
    
    public Jugador(String alias, int puntajePartida, int puntajeMax) {
        this.alias = alias;
        this.puntajePartida = puntajePartida;
        this.puntajeMax = puntajeMax;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getPuntajePartida() {
        return puntajePartida;
    }

    public void setPuntajePartida(int puntajePartida) {
        this.puntajePartida = puntajePartida;
    }

    public int getPuntajeMax() {
        return puntajeMax;
    }

    public void setPuntajeMax(int puntajeMax) {
        this.puntajeMax = puntajeMax;
    }
    
}
